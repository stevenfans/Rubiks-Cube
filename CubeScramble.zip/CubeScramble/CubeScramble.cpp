#include "Scramble.cpp"
#include <random>
#include <string>
#include <stdio.h>
#include <stdint.h>
#include <iostream>
#include <fstream>
#include <sstream>
// UART stuff
#include <errno.h>
#include <wiringPi.h>
#include <wiringSerial.h>
#include <stdbool.h>
#include <termios.h>
#include <errno.h>
#include <stdint.h>
#include <fcntl.h>
#include <unistd.h>

using namespace std;

void txInstruction(unsigned char* tx);
int fd; int res; unsigned char buf[255];
int main()
{
	//======================UART========================
  printf("opening up the file descriptor...\n");
  fd = open("/dev/serial0",O_RDWR | O_NOCTTY);//   | O_NONBLOCK|O_NDELAY);  
  printf("file descriptor opened on fd \n"); 
  struct termios options; 
  tcgetattr(fd,&options); 
  options.c_cflag = B9600 | CS8 | CLOCAL | CREAD; 
  options.c_iflag = IGNPAR; 
  options.c_oflag = 0; 
  options.c_lflag = 0; 
  tcflush(fd, TCIFLUSH); 
  tcsetattr(fd,TCSANOW, &options); 
  /*
  //check if UART is good to go
     if(fd<0){
    fprintf (stderr, "Unable to open serial device: %s\n", strerror (errno)) ;
    return 1 ;
  }
  if (wiringPiSetup () == -1){
    fprintf (stdout, "Unable to start wiringPi: %s\n", strerror (errno)) ;
    return 1 ;
  }
  */
  //serialFlush(fd); 
//==================================================
	random_device rd;
	mt19937 eng(rd());
	uniform_int_distribution<> distr(0,5);
	uniform_int_distribution<> distr2(0,1);

	int r0, r1, r2;
	unsigned char * instrTx;
	
	for(int i = 0; i < 25; i++){
		r0 = distr2(eng); r1 = distr(eng); r2 = distr2(eng);
		instrTx = createInstruction(r0, r1, r2);
		txInstruction(instrTx);
		usleep(140000);
		// RX Confirmation here
	}
	return 0;
}

void txInstruction(unsigned char* tx) {
	for (int i = 0; i < 8; i++) {
		serialPutchar(fd, tx[i]);
	}
	cout << "TX: ";
	for(int i = 0; i < 8; i++){
		cout << tx[i];
	}
	cout << "\n\r";
}
