#include <stdlib.h>
using namespace std;

unsigned char* createInstruction(char cw, char m, char s) {
	unsigned char *instruction = (unsigned char *)malloc(8);

	instruction[0] = '$';
	instruction[1] = 'O';

	switch (s) {
		case 0: instruction[2] = '1'; break;
		case 1: instruction[2] = '1'; break;
	}

	switch (cw) {
		case 0: instruction[3] = 'N'; break;
		case 1: instruction[3] = 'Y'; break;
	}

	switch (m) {
		case 0: instruction[4] = 'A'; break;
		case 1: instruction[4] = 'B'; break;
		case 2: instruction[4] = 'C'; break;
		case 3: instruction[4] = 'D'; break;
		case 4: instruction[4] = 'E'; break;
		case 5: instruction[4] = 'F'; break;
	}

	instruction[5] = '!';
	instruction[6] = 0;

	// checksum
	for (int i = 0; i < 5; i++) {
		//cout << instruction[i + 1];
		instruction[6] += instruction[i + 1];
	}

	// Invert bits
	//cout << (unsigned short)instruction[6];
	instruction[6] = 255 - instruction[6]; //checksum

	instruction[7] = '&';

	return instruction;
}
