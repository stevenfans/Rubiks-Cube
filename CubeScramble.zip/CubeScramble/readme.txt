Jose - 10 Dec 2019

Compile: g++ -o mainScramble.o CubeScramble.cpp uartrpi.c uartrpi.h -L/usr/X11R6/lib -lm -lpthread -lX11 -lwiringPi

*Note: Including Scramble.cpp causes double linking error, -lX11 must be capital X or compile fails

About: Run script to randomly scramble cube between 25-50 times