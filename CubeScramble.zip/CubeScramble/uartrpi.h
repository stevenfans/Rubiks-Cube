
void uart_tx_string (unsigned char *tx_string);
char checkRxBytes();
int not_main();

